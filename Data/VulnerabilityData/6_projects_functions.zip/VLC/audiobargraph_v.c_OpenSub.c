 */
static int OpenSub(vlc_object_t *p_this)
{
    return OpenCommon(p_this, true);
}
