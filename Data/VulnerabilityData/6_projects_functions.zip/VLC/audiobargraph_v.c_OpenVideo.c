 */
static int OpenVideo(vlc_object_t *p_this)
{
    return OpenCommon(p_this, false);
}
